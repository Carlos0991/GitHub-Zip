=================
Conociendo GitHub
=================

Sobre el tutorial:
------------------

En este tutorial creado en reStructuredText, por medio de Sphinx, se detallan cosas básicas sobre GitHub. 

Como por ejemplo:

1. ¿Qué es?
2. ¿Para qué sirve?
3. ¿Qué herramientas proporciona?
4. ¿Cómo crearse una cuenta?
5. ¿Cómo crear repositorios?
6. ¿Cómo colaborar en otros proyectos? - (**Fork** y **Pull**)


Acerca de...
------------

Este tutorial fue creado por Luciano Castillo (alumno programador del ITS Villada, Córdoba capital), con el fin de utilizar esta gran herramienta que nos brinda GitHub.


<a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/deed.es"><img alt="Licencia Creative Commons" style="border-width:0" src="http://i.creativecommons.org/l/by-sa/3.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">Conociendo GitHub</span> por <a xmlns:cc="http://creativecommons.org/ns#" href="https://github.com/LuchoCastillo/Conociendo-GitHub" property="cc:attributionName" rel="cc:attributionURL">Luciano Castillo</a> se encuentra bajo una <a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/deed.es">Licencia Creative Commons Atribución-CompartirIgual 3.0 Unported</a>.